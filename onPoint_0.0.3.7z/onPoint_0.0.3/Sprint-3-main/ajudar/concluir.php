<?php



$con = mysqli_connect('localhost','root','','bd_onpoint') or die ("erro de conexao"); //cria a conexao
$id = mysqli_real_escape_string($con, $_POST['conc']);

$query = "DELETE FROM ajudar WHERE id_ajuda = $id;";
$query_run = mysqli_query($con, $query);

if($query_run)
{
    echo "<script type='text/javascript'>alert('Ajuda concluida!');"; 
    echo "javascript:window.location='index.php';</script>";
}
else
{
    // echo "<script type='text/javascript'>alert('Algo deu errado :(');"; 
    // echo "javascript:window.location='index.php';</script>";
}
?>