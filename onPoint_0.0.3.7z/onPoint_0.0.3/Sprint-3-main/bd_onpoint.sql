create database bd_onpoint;
use bd_onpoint;

-- ATENCAO!!! QUANDO FOR CRIAR O BANCO LEMBRE-SE DE CRIAR O TRIGGER ABAIXO DO DELIMITER!!!
-- drop database bd_onpoint;

/* INSERTS DE EXEMPLO
insert into usuario values(null,'cassio','cassio@com.br','123');
insert into item values(null,'blusa','','',1);
insert into item values(null,'calça','','',1);
insert into item values(null,'tenis','','',1);
insert into look values(null,'algudao doce','','','','','',1);
insert into look_item values(1,1);
insert into look_item values(1,2);
insert into look_item values(1,3);
*/

/* SELECT JOIN ENTRE LOOK - LOOK_ITEM - ITEM
select l.id, l.nome
from look as l join look_item as li
on l.id = li.look_id
join item as i
on i.id = li.look_id
WHERE i.id_guarda = 1 AND l.id_guarda = 1;
*/

/* SELECT JOIN PARA CHAMAR AS IMAGENS DE CADA LOOK
select i.id, i.nome, i.arquivo
from item as i join look_item as il
on i.id = il.item_id
where il.look_id = 1 and i.id_guarda = 1;
*/

/* DELETAR TODOS OS DADOS DAS TABELAS
delete from look_item where look_id != 0;
delete from ajudar where id != 0;
delete from look where id != 0;
delete from item where id != 0;
delete from guarda where id != 0;
delete from usuario where id != 0;
*/

/* TODOS OS SELECTES DE CADA TABELA*/
 select * from usuario;
 select * from guarda;
 select * from item;
 select * from ajudar;
 select * from look;
 select * from look_item;
*/;
DELETE FROM look_item WHERE look_id = 2 and id_guarda = 1;
/*select *
from ajudar join look
on look.id = ajudar.id_look
WHERE ajudar.id = 1;

select * from ajudar;*/

create table usuario(
id_usuario int unsigned auto_increment not null primary key,
nome varchar(80) not null,
email varchar(80) not null,
senha varchar(40) not null
)engine=innodb;

create table guarda(
id_guarda int unsigned auto_increment not null primary key,
id_usuario int unsigned not null,
foreign key(id_usuario) references usuario(id_usuario)
)engine=innodb;

create table item(
id_item int unsigned auto_increment not null primary key,
nome varchar(100) not null,
descricao varchar(150),
arquivo blob,
id_guarda int unsigned not null,
foreign key(id_guarda) references guarda(id_guarda)
)engine=innodb;

create table look(
id_look int unsigned auto_increment not null primary key,
nome varchar(100) not null,
evento varchar(50),
estilo varchar(20),
horario time,
clima varchar(50),	
descricao varchar(150),
id_guarda int unsigned not null,
foreign key(id_guarda) references guarda(id_guarda)
)engine=innodb;

create table look_item(
look_id int unsigned not null,
item_id int unsigned not null,
id_guarda int unsigned not null,
primary key (look_id,item_id),
foreign key (look_id) references look(id_look),
foreign key (item_id) references item(id_item),
foreign key (id_guarda) references guarda(id_guarda)
)engine=innodb;

create table ajudar(
id_ajuda int unsigned auto_increment not null primary key,
dt datetime not null,
id_guarda int unsigned not null,
id_usuarior int unsigned not null,
id_usuarioe int unsigned not null,
id_look int unsigned not null,
foreign key(id_guarda) references guarda(id_guarda),
foreign key(id_usuarior) references usuario(id_usuario),
foreign key(id_usuarioe) references usuario(id_usuario),
foreign key(id_look) references look(id_look)
)engine=innodb;
delimiter $$

CREATE DEFINER = CURRENT_USER TRIGGER `bd_onpoint`.`usuario_AFTER_INSERT` AFTER INSERT ON `usuario` FOR EACH ROW
BEGIN
 insert into guarda values (null,new.id_usuario);
END
$$
