<?PHP

session_start();
$_SESSION['look'] = $_POST['atu'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <form method="post" action="atu_look.php">
        evento: <input type="text" name="evento"><br>
        estilo: <input type="text" name="estilo"><br>
        horario: <input type="time" name="horario"><br>
        clima: <input type="text" name="clima"><br>
        descricao: <input type="text" name="descricao"><br>
        nome do look: <input type="text" name="nome"><br><br>
        <button type="submit" name="att" value="<?php $_POST['atu'] ?>">atualizar</button>
    </form>
    <a href="../index.php"><button>voltar</button></a>
</body>

</html>