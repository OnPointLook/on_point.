<?php

session_start();
// pega o id do usuario
$id_usuario = $_SESSION['id'];
// inicia a conexao
$con = mysqli_connect("localhost", "root", "", "bd_onpoint") or die("erro de conexao");

$nome = mysqli_real_escape_string($con, $_POST["nome"]);
$evento = mysqli_real_escape_string($con, $_POST["evento"]);
$estilo = mysqli_real_escape_string($con, $_POST["estilo"]);
$horario = mysqli_real_escape_string($con, $_POST["horario"]);
$clima = mysqli_real_escape_string($con, $_POST["clima"]);
$descricao = mysqli_real_escape_string($con, $_POST["descricao"]);

$query = "SELECT * FROM look WHERE id_guarda = $id_usuario AND nome = '$nome';";
$query_run = mysqli_query($con, $query);

if (mysqli_num_rows($query_run) > 0) {
    echo "<script type='text/javascript'>alert('Este look ja existe!');";
    echo "javascript:window.location='index.php';</script>";
} else {
    $query_insert = "INSERT INTO look VALUES(NULL,'$nome','$evento','$estilo','$horario','$clima','$descricao',$id_usuario);";
    $query_run = mysqli_query($con, $query_insert);
    if ($query_run) {
        // redirecionar para a add item
        echo "<script type='text/javascript'>alert('Look criado!');";
        echo "javascript:window.location='index.php';</script>";
    } else {
        echo "<script type='text/javascript'>alert('Look não criado!');";
        echo "javascript:window.location='index.php';</script>";
    }
}
?>