<?php

session_start();
// puxa o id do uduario (que é o mesmo do querda roupa sem exceção pelo trigger no bd)
$id_usuario = $_SESSION['id'];
// abre a conexao
$con = mysqli_connect("localhost", "root", "", "bd_onpoint") or die("erro de conechao");
// puxa o nome e o blob(blob é uma imagem em formato de string) do item
$query = "SELECT * FROM usuario WHERE id_usuario = '$id_usuario';";
$query_run = mysqli_query($con, $query);
// se der certo, ele atribui a um arry
if (mysqli_num_rows($query_run) > 0) {
    $item = mysqli_fetch_array($query_run);
    $nome = $item['nome'];
}
if ($item['arquivo'] == '') {
    $gambi = 1;
} else {
    $gambi = 2;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <form action="atu_nome.php" method="post">
        nome: <input type="text" name="nome" value="<?php echo $nome ?>" required><br>
        <input type="submit" value="confirmar">
    </form>
    <?php

    if ($gambi == 1) {
    ?>
        <img src="..\img\default.png" width="50px" height="50px" />
    <?php
    } else {
    ?>
        <img src="data:image/png;base64,<?= $item['arquivo'] ?>" width="10%" height="10%" />
    <?php
    }

    ?>
    <form enctype="multipart/form-data" action="atu_foto.php" method="post">
        <input name="foto" type="file" required><br><br>
        <input type="submit" value="confirmar">
    </form>

    <br><br><a href="../index.php"><button>voltar</button></a>

</body>

</html>