<?php

session_start();
$id_usuario = $_SESSION["id"];

$con = mysqli_connect('localhost', 'root', '', 'bd_onpoint') or die("erro de conexao"); //cria a conexao
$look = mysqli_real_escape_string($con, $_POST['del']);
var_dump($look);
var_dump($id_usuario);
$query = "DELETE FROM ajudar WHERE id_look = $look;";
$query_run = mysqli_query($con, $query);

$query = "DELETE FROM look_item WHERE look_id = $look and id_guarda = $id_usuario;";
$query_run = mysqli_query($con, $query);


$query = "DELETE FROM look WHERE id_look = $look and id_guarda = $id_usuario;";
$query_run = mysqli_query($con, $query);

if ($query_run) {
    echo "<script type='text/javascript'>alert('Look excluido!');";
    echo "javascript:window.location='../index.php';</script>";
} else {
    echo "<script type='text/javascript'>alert('Look nao excluido!');";
    echo "javascript:window.location='../index.php';</script>";
}
?>