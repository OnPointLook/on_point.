<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <a href="criar_look/index.php"><button>add_look</button></a>
    <?php

    session_start();
    // puxa o id do usuario (que é o mesmo do guarda roupa sem exceção pelo trigger no bd)
    $id_usuario = $_SESSION['id'];

    // abre a conexao
    $con = mysqli_connect("localhost", "root", "", "bd_onpoint") or die("erro de conechao");
    // puxa o nome e o blob(blob é uma imagem em formato de string) do item
    $query = "SELECT * FROM look WHERE id_guarda = $id_usuario;";

    $query_run = mysqli_query($con, $query);
    if (mysqli_num_rows($query_run) > 0) {
        $look = mysqli_fetch_array($query_run);
        $look_id = $look['id_look'];
        
        foreach ($query_run as $look) {

            echo "<br><br>" . "nome do look: " . $look['nome'] . "<br><br>";


            $query =    "SELECT * FROM look AS l 
                        JOIN look_item AS li
                        ON l.id_look = li.look_id
                        JOIN item AS i
                        ON i.id_item = li.item_id
                        WHERE l.id_look = $look_id
                        AND l.id_guarda = $id_usuario;";

            // se der certo, ele atribui a um array

            $query_run1 = mysqli_query($con, $query);
            if (mysqli_num_rows($query_run1) > 0) {
                $look_item = mysqli_fetch_array($query_run1);
                $lId = $look['id_look'];

                $query = "SELECT *
                                    FROM item AS i JOIN look_item AS il
                                    ON i.id_item = il.item_id
                                    WHERE il.look_id = $lId AND i.id_guarda = $id_usuario;";
                                    $query_run2 = mysqli_query($con, $query);
                                    // se der certo, ele atribui a um array
                                    if (mysqli_num_rows($query_run2) > 0) {
                                        $item = mysqli_fetch_array($query_run2);
                                        
                                        foreach ($query_run2 as $item) {
                                            
                                            
                                            ?>
                                            <img src="data:image/png;base64,<?= $item['arquivo'] ?>" width="50px" height="50px" />
                                            <?php
                                            
                                        }
                                        
                                    }
                
                                ?>




                                
                                </div>
                                <!-- a linha abaixo é o metodo utilizado para imprimir o blob em forma de imagem -->
                            </a>
                        </td>
                    </tr>
                <?php
            }else{ echo "Nem um item vinculado ao look";}
                ?>
                <form action="atu_look/index.php" method="POST">
                    <button type="submit" name="atu" value="<?= $look['id_look']; ?>">Atualizar</button>
                </form>
                <form action="del_look/del.php" method="POST">
                    <button type="submit" name="del" value="<?= $look['id_look']; ?>">Deletar</button>
                </form>
                <form action="add_look/index.php" method="POST">
                    <button type="submit" name="add" value="<?=$look['id_look']; ?>">Adicionar look</button>
                </form>
        <?php
        }
    }
        ?>
        <br><br>
<a href="../Tela-Perfil/index.php"><button>voltar</button></a>
</body>

</html>