<?php
session_start();
// puxa a descricao do evento
$id_usuario = $_SESSION["id"];
$con = mysqli_connect("localhost", "root", "", "bd_onpoint") or die("erro de conechao");
$evento = mysqli_real_escape_string($con, $_POST["evento"]);
$estilo = mysqli_real_escape_string($con, $_POST["estilo"]);
$horario = mysqli_real_escape_string($con, $_POST["horario"]);
$clima = mysqli_real_escape_string($con, $_POST["clima"]);
$descricao = mysqli_real_escape_string($con, $_POST["descricao"]);
$nome = mysqli_real_escape_string($con, $_POST["look"]);
$receptor = mysqli_real_escape_string($con, $_POST["receptor"]);

// confere se o email do receptor é valido
$query_select = "SELECT * FROM usuario WHERE email = '$receptor';";

$result = $con->query($query_select);
// se funcionar ele cria o pedido se n, avisa que deu erro
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $receptor = $row['id_usuario'];
    

    $query_insert = "INSERT INTO look VALUES(NULL,'$nome','i','$evento','$estilo','$horario','$clima','$descricao',$id_usuario);";
    $query_run1 = mysqli_query($con, $query_insert);
    if ($query_run1) {
        $query_select = "SELECT id_look FROM look WHERE nome = '$nome' and id_guarda = $id_usuario;";
        echo "aaaaaaaaaa";
        $result1 = $con->query($query_select);
        // se funcionar ele cria o pedido se n, avisa que deu erro
        if ($result1->num_rows > 0) {
            $row1 = $result1->fetch_assoc();
            $id_look = $row1['id_look'];

            $query_insert = "INSERT INTO ajudar VALUES(NULL, now(),$id_usuario,$receptor,$id_usuario,$id_look);";
            $query_run = mysqli_query($con, $query_insert);
            if ($query_run) {
                // redirecionar para a home

                echo "<script type='text/javascript'>alert('Ajuda solicitada!');";
                echo "javascript:window.location='index.html';</script>";
            } else {
                echo "<script type='text/javascript'>alert('Falha ao enviar');";
                echo "javascript:window.location='./index.html';</script>";
            }
        }
    }else {
        echo "<script type='text/javascript'>alert('Falha ao enviar');";
        echo "javascript:window.location='./index.html';</script>";
    }
} else {
    echo "<script type='text/javascript'>alert('usuario inexistente');";
    echo "javascript:window.location='./index.html';</script>";
}
