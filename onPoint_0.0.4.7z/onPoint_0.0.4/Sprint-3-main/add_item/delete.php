<?php
session_start();
$id_usuario = $_SESSION["id"];
echo "<script type='text/javascript'>alert('ATENÇÃO! TODOS OS LOOKS VINCULADOS A ESTE ITEM SERA MODIFICADO!');</script>";

$con = mysqli_connect('localhost', 'root', '', 'bd_onpoint') or die("erro de conexao"); //cria a conexao
$item = mysqli_real_escape_string($con, $_POST['del']);

$query = "DELETE FROM look_item WHERE item_id = $item and id_guarda = $id_usuario;";
$query_run = mysqli_query($con, $query);
if ($query_run) {

    $query = "DELETE FROM item WHERE id_item = $item and id_guarda = $id_usuario";
    $query_run = mysqli_query($con, $query);

    if ($query_run) {
        echo "<script type='text/javascript'>alert('item excluido!');"; //alert em JS de erro
        echo "javascript:window.location='./index.php';</script>";
    } else {
        echo "<script type='text/javascript'>alert('item nao excluido!');"; //alert em JS de erro
        echo "javascript:window.location='./index.php';</script>";
    }
}
?>