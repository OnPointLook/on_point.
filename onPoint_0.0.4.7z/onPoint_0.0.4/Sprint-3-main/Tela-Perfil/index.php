<?php
    if(!isset($_SESSION)){
        session_start();
    }
    $id_usuario = $_SESSION['id'];
    include('./assets/seguranca.php');

    $con = mysqli_connect('localhost','root','','bd_onpoint') or die ("erro de conexao"); //cria a conexao

    $query_select = "SELECT * FROM USUARIO WHERE id_usuario = $id_usuario;";
    $result = $con->query($query_select);

    if($result->num_rows >0){
      $row = $result->fetch_assoc();
    
    }
    $nome = $row['nome'];


?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OnPoint - Perfil</title>
    <link rel="stylesheet" href="./assets/stylePerfil.css">

    <!--BS5-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="./assets/node_modules/bootstrap-icons/font/bootstrap-icons.css">
</head>
<div>
    
    <!-- Navbar -->
    <nav class="navbar navbar-light bg-light" style="background-color: #8c52ff!important;">
        <div class="container-fluid">
          <a class="navbar-brand text-white" href="#">
            <img src="./img/logopit.jpg" alt="" width="40" height="40" class="d-inline-block align-text-top">
            OnPoint
          </a>
          <ul class="nav justify-content-center">  
            <li class="nav-item">
              <a href="./assets/logout.php" class="btn btn-outline-light" title="LogOut"><i class="bi bi-box-arrow-right"></i></a>
            </li>
          </ul>
        </div>
      </nav>

      <!-- Foto e Infos -->
      <div class="container my-4">
          <div class="profile">
            <?php 
              if($row['arquivo'] == ''){
                ?>
                <img src="img/default.png" alt="foto-perfil" class="profilePic" />
                <?php
              }else{
                ?>
                <img src="data:image/png;base64,<?= $row['arquivo'] ?>" alt="foto-perfil" class="profilePic" />
                <?php
              }
            ?>
            
            <p style="transform: translate(0,90px); font-size: 22px; width: 80%;"><?php echo $nome ?></p>

            <p class="text-muted" style="transform: translate(0,100px); font-size: 18px;">Sua bio aqui</p>

              <a href="editar_perfil/index.php" id="cagado"> <input type="submit" value="EDITAR PERFIL" class="btn btn-outline-light" style="margin-left: 80vh; background-color: #8c52ff;"></a>

            <br style="clear: both;">
          </div>
          <main>
            <ul class="nav justify-content-center">
              <li class="nav-item">
                <a href="../add_item/index.php" class="btn btn-outline-light" title="Adicionar Items"><i class="bi bi-door-open-fill"></i></a>
              </li>
              <li class="nav-item">
                <a href="../pedir_ajuda/index.html" class="btn btn-outline-light" title="Pedir Ajuda"><i class="bi bi-chat-left-dots-fill"></i></a>  
              </li>
              <li class="nav-item">
                <a href="../ajudar/index.php" class="btn btn-outline-light" title="Ajudar"><i class="bi bi-chat-right-dots-fill"></i></a>
              </li>
              <li class="nav-item">
                <a href="../look/index.php" class="btn btn-outline-light" title="Ajudar"><i class="bi bi-chat-right-dots-fill"></i></a>
              </li>
          </ul>
          </main>
      </div>

      <!-- Grid de looks -->
      <di class="container grid-looks text-center">
        <div class="row">
          <div class="col-3">
           
            <!-- comeca aqui -->
            <?php
            $query = "SELECT * FROM look WHERE publico = 'o';";
            
            $query_run = mysqli_query($con, $query);
            if (mysqli_num_rows($query_run) > 0) {
              $look = mysqli_fetch_array($query_run);
              $look_id = $look['id_look'];
              foreach ($query_run as $look) {
                ?>
                 <div class="card">
                   <?php
                


                $query =  "SELECT * FROM look AS l 
                          JOIN look_item AS li
                          ON l.id_look = li.look_id
                          JOIN item AS i
                          ON i.id_item = li.item_id
                          WHERE l.id_look = $look_id
                          AND l.publico = 'o';";

                          $query_run1 = mysqli_query($con, $query);
                          if (mysqli_num_rows($query_run1) > 0) {
                            $look_item = mysqli_fetch_array($query_run1);
                            $lId = $look['id_look'];

                            $query = "SELECT *
                                    FROM item AS i JOIN look_item AS il
                                    ON i.id_item = il.item_id
                                    WHERE il.look_id = $lId /*AND i.id_guarda = $id_usuario*/;";
                                    $query_run2 = mysqli_query($con, $query);
                                    // se der certo, ele atribui a um array
                                    if(mysqli_num_rows($query_run2) > 0) {
                                      $item = mysqli_fetch_array($query_run2);
                                        ?>
                                        <div class="card-img-top p-2 rounded-4">
                                        <?php
                                        foreach($query_run2 as $item) {  
                                          ?>
                                            <img src="data:image/png;base64,<?= $item['arquivo'] ?>" width="50px" height="50px" />
                                          <?php ;
                                            
                                        }
                                        ?>
                                        </div>
                                        <?php
                                      }
                                  }
                                  ?>
                                    <h3 class="card-title"><?php echo $look['nome']?></h3>
                                    <p class="card-text text-muted"><?php echo $look['descricao']?></p>
                 </div><br><br>
                                  <?php
                                  

                                }
                              }
                
                                ?>
                            </a>
                        </td>
                    </tr>
              <div class="card-body">
                <!-- <img src="./img/logopit.jpg" alt="" class="card-img-top p-2 rounded-4"> -->
                
                
              </div>
              <!--
            </div>
          </div>
          <div class="col-3">
            <div class="card">
              <div class="card-body">
                <img src="./img/logopit.jpg" alt="" class="card-img-top p-2 rounded-4">
                <h3 class="card-title">Nome-item</h3>
                <p class="card-text text-muted">Descricao do Item da Imagem</p>
              </div>
            </div>
          </div>
          <div class="col-3">
            <div class="card">
              <div class="card-body">
                <img src="./img/logopit.jpg" alt="" class="card-img-top p-2 rounded-4">
                <h3 class="card-title">Nome-item</h3>
                <p class="card-text text-muted">Descricao do Item da Imagem</p>
              </div>
            </div>
          </div>
          <div class="col-3">
            <div class="card">
              <div class="card-body">
                <img src="./img/logopit.jpg" alt="" class="card-img-top p-2 rounded-4">
                <h3 class="card-title">Nome-item</h3>
                <p class="card-text text-muted">Descricao do Item da Imagem</p>
              </div>
            </div>
          </div>
  -->
        </div>
      </div>
    <!--BS5-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
</body>
</html>