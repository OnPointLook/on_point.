<?PHP

session_start();
$_SESSION['look'] = $_POST['atu'];
$look = $_POST['atu'];
$id_usuario = $_SESSION['id'];

$con = mysqli_connect("localhost", "root", "", "bd_onpoint") or die("erro de conexao");

$query = "SELECT * FROM look WHERE id_guarda = $id_usuario AND id_look = '$look';";
$query_run = mysqli_query($con, $query);
if (mysqli_num_rows($query_run) > 0) {
    $look = mysqli_fetch_array($query_run);
    $evento = $look['evento'];
    $estilo = $look['estilo'];
    $horario = $look['horario'];
    $clima = $look['clima'];
    $descricao = $look['descricao'];
    $nome = $look['nome'];
}else{
    
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <form method="post" action="atu_look.php">
        evento: <input type="text" name="evento" value="<?php echo $evento ?>"><br>
        estilo: <input type="text" name="estilo" value="<?php echo $estilo ?>"><br>
        horario: <input type="time" name="horario" value="<?php echo $horario ?>"><br>
        clima: <input type="text" name="clima" value="<?php echo $clima ?>"><br>
        descricao: <input type="text" name="descricao" value="<?php echo $descricao ?>"><br>
        nome do look: <input type="text" name="nome" value="<?php echo $nome ?>" required><br>
        <input type="radio" name="postar" value="o" required>postar
        <input type="radio" name="postar" value="i" required>privar<br><br>
        <button type="submit" name="att" value="<?php $_POST['atu'] ?>">atualizar</button>
    </form>
    <a href="../index.php"><button>voltar</button></a>
</body>

</html>