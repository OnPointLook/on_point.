<?php

session_start();
// puxa o id do usuario (que é o mesmo do guarda roupa sem exceção pelo trigger no bd)
$id_usuario = $_SESSION['id'];

// abre a conexao
$con = mysqli_connect("localhost", "root", "", "bd_onpoint") or die("erro de conechao");
// $id_ajuda = mysqli_real_escape_string($con,$_POST["ajudar"]);
$id_ajuda = $_SESSION['id_ajudar'];
$query_select = "SELECT * 
    FROM ajudar JOIN look
    ON look.id_look = ajudar.id_look
    WHERE ajudar.id_ajuda = $id_ajuda;";
$result = $con->query($query_select);
if ($result->num_rows > 0) {

    // imprime os dados do evento na tela
    $row = $result->fetch_assoc();
    $id_ajudado = $row['id_usuarioe'];
    echo "evento: " . $row['evento'] . "<br>";
    echo "estilo: " . $row['estilo'] . "<br>";
    echo "horario: " . $row['horario'] . "<br>";
    echo "clima: " . $row['clima'] . "<br>";
    echo "descricao: " . $row['descricao'] . "<br>";
    echo "nome do look: " . $row['nome'] . "<br>";

    $look_id = $row['id_look'];
    $_SESSION['look_id'] = $look_id;
    $_SESSION['id_ajudado'] = $id_ajudado;

    $query = "SELECT * FROM item WHERE id_guarda = '$id_ajudado';";
    $query_run = mysqli_query($con, $query);
    // se der certo, ele atribui a um arry
    if (mysqli_num_rows($query_run) > 0) {
        $item = mysqli_fetch_array($query_run);
    }
} else {
    // echo "<script type='text/javascript'>alert('SEM PEDIDOS DE AJUDA');";
    // echo "javascript:window.location='../Tela-Perfil/index.php';</script>";
}

?>

<?php
// imprime os itens para adicionar a um look
$query = "SELECT * FROM look WHERE id_guarda = $id_ajudado and id_look = $look_id;";

$query_run = mysqli_query($con, $query);
if (mysqli_num_rows($query_run) > 0) {
    $look = mysqli_fetch_array($query_run);

    foreach ($query_run as $look) {

        // echo "<br><br>" . "nome do look: " . $look['nome'] . 
        echo "<br><br>";

        $query =    "SELECT * FROM look AS l 
                            JOIN look_item AS li
                            ON l.id_look = li.look_id
                            JOIN item AS i
                            ON i.id_item = li.item_id
                            WHERE l.id_look = $look_id
                            AND l.id_guarda = $id_ajudado;";

        // se der certo, ele atribui a um array

        $query_run1 = mysqli_query($con, $query);
        if (mysqli_num_rows($query_run1) > 0) {
            
            $look_item = mysqli_fetch_array($query_run1);
            $lId = $look['id_look'];

            $query = "SELECT *
                                        FROM item AS i JOIN look_item AS il
                                        ON i.id_item = il.item_id
                                        WHERE il.look_id = $lId AND i.id_guarda = $id_ajudado;";
            $query_run2 = mysqli_query($con, $query);
            // se der certo, ele atribui a um array
            if (mysqli_num_rows($query_run2) > 0) {
                $item = mysqli_fetch_array($query_run2);

                foreach ($query_run2 as $item) {

?>
                    <img src="data:image/png;base64,<?= $item['arquivo'] ?>" width="50px" height="50px" />
                    <form action="add_ajuda/del_item_ajuda.php" method="POST">
                        <button type="submit" name="del" value="<?= $item['id_item']; ?>">Deletar</button>
                    </form>
        <?php

                }
            }
        }
    }
}
$query = "SELECT * FROM item WHERE id_guarda = $id_ajudado;";
$query_run0 = mysqli_query($con, $query);
// se der certo, ele atribui a um arry
if (mysqli_num_rows($query_run0) > 0) {
    $itemm = mysqli_fetch_array($query_run0);

    foreach ($query_run0 as $itemm) {
        ?>
        <tr>
            <td>
                <div>
                    <?= $itemm['nome'];
                    $_SESSION['item_id'] = $itemm['id_item']; ?><br>
                    <!-- a linha abaixo é o metodo utilizado para imprimir o blob em forma de imagem -->
                    <img src="data:image/png;base64,<?= $itemm['arquivo'] ?>" width="50px" height="50px" />
                    <form action="add_ajuda/add_item_ajuda.php" method="POST">
                        <button type="submit" name="add" value="<?= $itemm['id_item']; ?>">Adicionar</button>
                    </form>
                </div>
            </td>
        </tr>
<?php
    }
}
?>
<form action="concluir.php" method="POST">
    <button type="submit" name="conc" value="<?= $id_ajuda; ?>">finalizar</button>
</form>
<form action="../Tela-Perfil/index.php">
    <button>home</button>
</form>

</body>