<?php

$con = mysqli_connect("localhost","root","","bd_onpoint");

if(!$con){
die('Connection Failed'. mysqli_connect_error());
}
?>