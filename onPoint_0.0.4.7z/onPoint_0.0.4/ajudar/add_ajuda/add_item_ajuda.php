<?php

session_start();
// pega o id do usuario
$id_usuario = $_SESSION['id'];
$_SESSION['item_id'] = $_POST['add'];
// inicia a conexao
$con = mysqli_connect("localhost","root","","bd_onpoint") or die ("erro de conexao");
$look_id = $_SESSION['look_id'];
$item_id = $_SESSION['item_id'];
$id_ajudado = $_SESSION['id_ajudado'];

// faz o insert no bd
$query_insert = "INSERT INTO look_item VALUES($look_id,$item_id,$id_ajudado);";
$query_run = mysqli_query($con, $query_insert);
if($query_run){
    // redirecionar para a add item
    echo "<script type='text/javascript'>alert('Item adicionado!');";
    echo "javascript:window.location='../ajudar.php';</script>";
}else{
    echo "<script type='text/javascript'>alert('Item não adicionado!O item não pode estar duas vezes no mesmo look');";
    echo "javascript:window.location='../ajudar.php';</script>";
}

?>