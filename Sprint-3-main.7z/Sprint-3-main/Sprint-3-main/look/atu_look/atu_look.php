<?php

session_start();
// pega o id do usuario
$id_usuario = $_SESSION['id'];
$look_id = $_SESSION['look'];
// inicia a conexao
$con = mysqli_connect("localhost","root","","bd_onpoint") or die ("erro de conexao");

$nome = mysqli_real_escape_string($con, $_POST["nome"]);
$evento = mysqli_real_escape_string($con, $_POST["evento"]);
$estilo = mysqli_real_escape_string($con, $_POST["estilo"]);
$horario = mysqli_real_escape_string($con, $_POST["horario"]);
$clima = mysqli_real_escape_string($con, $_POST["clima"]);
$descricao = mysqli_real_escape_string($con, $_POST["descricao"]);

// faz o insert no bd
$query_insert = " UPDATE look SET nome = '$nome', evento = '$evento', estilo = '$estilo', horario = '$horario', clima = '$clima', descricao = '$descricao' WHERE id_guarda = $id_usuario AND id = $look_id;";
$query_run = mysqli_query($con, $query_insert);
if($query_run){
    // redirecionar para a add item
    echo "<script type='text/javascript'>alert('look auterado!');";
    echo "javascript:window.location='../index.php';</script>";
}else{
    echo "<script type='text/javascript'>alert('Look nao encontrado!');";
    echo "javascript:window.location='../index.php';</script>";
}

?>