<?php

session_start();
$look_id = $_SESSION['look_id'];
$item_id = $_POST['del'];
var_dump($look_id);
var_dump($item_id);

$con = mysqli_connect('localhost','root','','bd_onpoint') or die ("erro de conexao"); //cria a conexao
$look = mysqli_real_escape_string($con, $_POST['del']);

$query = "DELETE FROM look_item WHERE look_id='$look_id' and item_id = $item_id";
$query_run = mysqli_query($con, $query);

if($query_run)
{
    echo "<script type='text/javascript'>alert('Item do look excluido!');"; 
    echo "javascript:window.location='index.php';</script>";
}
else
{
    echo "<script type='text/javascript'>alert('Item do look não excluido!');"; 
    echo "javascript:window.location='index.php';</script>";
}
?>