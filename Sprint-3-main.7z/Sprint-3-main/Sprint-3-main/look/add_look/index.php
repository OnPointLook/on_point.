<?php

session_start();
// puxa o id do uduario (que é o mesmo do querda roupa sem exceção pelo trigger no bd)
$id_usuario = $_SESSION['id'];
if(isset($_POST['add'])){
    $_SESSION['look_id'] = $_POST['add'];
}

    $look_id = $_SESSION['look_id'];
    var_dump($look_id);
    
// abre a conexao
$con = mysqli_connect("localhost", "root", "", "bd_onpoint") or die("erro de conechao");
// puxa o nome e o blob(blob é uma imagem em formato de string) do item

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
        <?php
        // imprime os itens para adicionar a um look
        $query = "SELECT * FROM look WHERE id_guarda = $id_usuario and id = $look_id;";

        $query_run = mysqli_query($con, $query);
        if (mysqli_num_rows($query_run) > 0) {
            $look = mysqli_fetch_array($query_run);
            $look_id = $look['id'];
            
            foreach ($query_run as $look) {
    
                echo "<br><br>" . "nome do look: " . $look['nome'] . "<br><br>";
    
                $query =    "SELECT * FROM look AS l 
                            JOIN look_item AS li
                            ON l.id = li.look_id
                            JOIN item AS i
                            ON i.id = li.item_id
                            WHERE l.id = $look_id
                            AND l.id_guarda = $id_usuario;";
    
                // se der certo, ele atribui a um array
    
                $query_run1 = mysqli_query($con, $query);
                if (mysqli_num_rows($query_run1) > 0) {
                    $look_item = mysqli_fetch_array($query_run1);
                    $lId = $look['id'];
    
                    $query = "SELECT *
                                        FROM item AS i JOIN look_item AS il
                                        ON i.id = il.item_id
                                        WHERE il.look_id = $lId AND i.id_guarda = $id_usuario;";
                                        $query_run2 = mysqli_query($con, $query);
                                        // se der certo, ele atribui a um array
                                        if (mysqli_num_rows($query_run2) > 0) {
                                            $item = mysqli_fetch_array($query_run2);
                                            
                                            foreach ($query_run2 as $item) {
                                                
                                                ?>
                                                    <img src="data:image/png;base64,<?= $item['arquivo'] ?>" width="50px" height="50px" />
                                                    <form action="del_item_look.php" method="POST">
                                                    <button type="submit" name="del" value="<?= $item['id']; ?>">Deletar</button>
                                                    <?php var_dump($item['id'])?>
                                                <?php
                                                
                                            }
                                            
                                        }
                                    }
                                }
                            }
        $query = "SELECT * FROM item WHERE id_guarda = '$id_usuario';";
        $query_run0 = mysqli_query($con, $query);
        // se der certo, ele atribui a um arry
        if (mysqli_num_rows($query_run0) > 0) {
            $itemm = mysqli_fetch_array($query_run0);

            foreach ($query_run0 as $itemm) {
                ?>
                    <tr>
                        <td>
                            <a href="">
                                <div>
                                    <?= $itemm['nome'];
                                    $_SESSION['item_id'] = $itemm['id']; ?><br>
                                    <!-- a linha abaixo é o metodo utilizado para imprimir o blob em forma de imagem -->
                                    <img src="data:image/png;base64,<?= $itemm['arquivo'] ?>" width="50px" height="50px" />
                                    <form action="add_item_look.php" method="POST">
                                        <button type="submit" name="add" value="<?= $itemm['id']; ?>">Adicionar</button>
                                    </form>
                                </div>
                            </a>
                        </td>
                    </tr>
                <?php
                }
                
        }
    ?>
    <a href="../index.php"><button>voltar</button></a>
</body>

</html>