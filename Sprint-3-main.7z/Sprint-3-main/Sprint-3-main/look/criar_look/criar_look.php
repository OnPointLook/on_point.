<?php

session_start();
// pega o id do usuario
$id_usuario = $_SESSION['id'];
// inicia a conexao
$con = mysqli_connect("localhost","root","","bd_onpoint") or die ("erro de conexao");
$look_id = $_SESSION['look_id'];
$nome = mysqli_real_escape_string($con, $_POST["nome"]);
$evento = mysqli_real_escape_string($con, $_POST["evento"]);
$estilo = mysqli_real_escape_string($con, $_POST["estilo"]);
$horario = mysqli_real_escape_string($con, $_POST["horario"]);
$clima = mysqli_real_escape_string($con, $_POST["clima"]);
$descricao = mysqli_real_escape_string($con, $_POST["descricao"]);


// faz o insert no bd
$query_insert = "INSERT INTO look VALUES(NULL,'$nome','$evento','$estilo','$horario','$clima','$descricao',$id_usuario);";
$query_run = mysqli_query($con, $query_insert);
if($query_run){
    // redirecionar para a add item
    echo "<script type='text/javascript'>alert('look criado!');";
    echo "javascript:window.location='index.php';</script>";
    $query = "SELECT * FROM look WHERE id_guarda = $id_usuario AND nome = '$nome';";
    $query_run = mysqli_query($con, $query);
    // se der certo, ele atribui a um arry
    if (mysqli_num_rows($query_run) > 0) {
        $lItem = mysqli_fetch_array($query_run);

        
    }
}else{
    echo "<script type='text/javascript'>alert('Item não adicionado!');";
    echo "javascript:window.location='index.php';</script>";
}

?>